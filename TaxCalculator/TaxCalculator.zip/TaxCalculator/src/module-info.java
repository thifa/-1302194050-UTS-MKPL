module TaxCalculator {
	
	
	
	
}